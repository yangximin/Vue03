const state = {a:'yxm'};
const mutation = {};
const actions = {};
const getters = {}
export default {
    state,
    mutation,
    actions,
    getters
}