const state = {b:30};
const mutation = {};
const actions = {};
const getters = {}
export default {
    state,
    mutation,
    actions,
    getters
}