<template>
  <div>
      我是登录
  </div>
</template>

<script>
export default {
   name:'login'
}
</script>

<style>

</style>