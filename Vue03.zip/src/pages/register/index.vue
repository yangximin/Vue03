<template>
  <div>
      我是注册
  </div>
</template>

<script>
export default {
   name:'register'
}
</script>

<style>

</style>