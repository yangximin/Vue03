<template>
  <div>我是搜索</div>
</template>

<script>
export default {
  name: "search",
};
</script>

<style>
</style>